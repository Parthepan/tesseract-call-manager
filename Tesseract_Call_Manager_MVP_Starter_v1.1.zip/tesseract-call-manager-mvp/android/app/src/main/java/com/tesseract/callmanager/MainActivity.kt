package com.tesseract.callmanager

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { EmployeeHome() } }
    }
}

data class SampleCall(val customer: String, val channel: String, val time: String, val outcome: String)

@Composable
fun EmployeeHome() {
    var tab by remember { mutableStateOf("Dashboard") }
    val sampleCalls = listOf(
        SampleCall("Customer A", "SIM", "10:30 AM", "Positive"),
        SampleCall("Customer B", "WhatsApp", "11:15 AM", "Follow-up"),
        SampleCall("Customer C", "SIM", "12:05 PM", "No answer")
    )
    Scaffold(
        topBar = {
            TopAppBarCompat()
        }
    ) { padding ->
        Column(Modifier.padding(padding).padding(16.dp)) {
            Text("Welcome to Tesseract", style = MaterialTheme.typography.titleLarge)
            Text("Employee business-call workspace", style = MaterialTheme.typography.bodyMedium)
            Spacer(Modifier.height(16.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Dashboard", "Calls", "Add call").forEach { item ->
                    FilterChip(selected = tab == item, onClick = { tab = item }, label = { Text(item) })
                }
            }
            Spacer(Modifier.height(16.dp))
            when (tab) {
                "Dashboard" -> {
                    Text("Today's activity", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(8.dp))
                    Text("Calls logged: 3  •  Positive: 1  •  Follow-ups: 1")
                    Spacer(Modifier.height(12.dp))
                    sampleCalls.forEach { call ->
                        Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                            Column(Modifier.padding(12.dp)) {
                                Text(call.customer, style = MaterialTheme.typography.titleSmall)
                                Text("${call.channel} • ${call.time} • ${call.outcome}")
                            }
                        }
                    }
                }
                "Calls" -> {
                    Text("Business call history", style = MaterialTheme.typography.titleMedium)
                    LazyColumn { items(sampleCalls) { call ->
                        ListItem(headlineContent = { Text(call.customer) },
                            supportingContent = { Text("${call.channel} • ${call.time}") },
                            trailingContent = { Text(call.outcome) })
                    } }
                }
                else -> ManualCallForm()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TopAppBarCompat() {
    TopAppBar(title = { Text("TESSERACT  |  CALL MANAGER") })
}

@Composable
fun ManualCallForm() {
    var customer by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var channel by remember { mutableStateOf("SIM") }
    var feedback by remember { mutableStateOf("POSITIVE") }
    var remarks by remember { mutableStateOf("") }
    var saved by remember { mutableStateOf(false) }

    Text("Log a business call", style = MaterialTheme.typography.titleMedium)
    OutlinedTextField(customer, { customer = it; saved = false }, label = { Text("Customer name") }, modifier = Modifier.fillMaxWidth())
    OutlinedTextField(phone, { phone = it; saved = false }, label = { Text("Business phone number (optional)") }, modifier = Modifier.fillMaxWidth())
    Text("Calling channel")
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        listOf("SIM", "WHATSAPP").forEach { value ->
            FilterChip(selected = channel == value, onClick = { channel = value }, label = { Text(value) })
        }
    }
    Text("Customer feedback")
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        listOf("POSITIVE", "NEGATIVE", "NEUTRAL").forEach { value ->
            FilterChip(selected = feedback == value, onClick = { feedback = value }, label = { Text(value) })
        }
    }
    OutlinedTextField(remarks, { remarks = it; saved = false }, label = { Text("Remarks / follow-up details") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
    Button(onClick = { saved = customer.isNotBlank() }, enabled = customer.isNotBlank(), modifier = Modifier.fillMaxWidth()) {
        Text("Save call (prototype)")
    }
    if (saved) Text("Prototype entry validated. Backend sync is not connected yet.", color = MaterialTheme.colorScheme.primary)
}
