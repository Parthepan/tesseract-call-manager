# MVP Product Specification

## Product
Tesseract Call Manager — private employee CRM and business call activity tracker.

## Roles
- Admin: one owner account; can view all employee/customer/call/follow-up data and manage employee access.
- Employee: can view and manage only their own assigned customers, business call records, and follow-ups.

## Calling channels
### SIM
MVP: manual business-call record entry. Later: optional Android call-log integration only after legal/privacy review and Google Play approval for the enterprise CRM exception. Do not request call-log permissions in the first MVP build.

### WhatsApp
MVP: manual business-call record entry. Employee profile stores the employee's designated business WhatsApp number. Do not inspect WhatsApp databases, notifications, accessibility events, or personal call history.

## Call fields
- Customer name and optional phone
- Channel: SIM / WHATSAPP
- Direction: INCOMING / OUTGOING
- Call start date/time
- Duration seconds
- Status: ANSWERED / UNANSWERED / DECLINED / UNKNOWN
- Feedback: POSITIVE / NEGATIVE / NEUTRAL / INTERESTED / NOT_INTERESTED
- Remarks
- Optional follow-up date/time

## Dashboard KPIs
- Calls logged in selected date range
- Answered calls and pickup rate
- Positive/interested feedback count
- Negative feedback count
- Pending/overdue follow-ups
- Sales conversions (Phase 1.1)

Pickup rate = answered business calls / business calls with known answer status × 100.

## Admin reports
- Filter by employee, date range, channel, status, feedback
- Export filtered call records to CSV (starter web dashboard)
- Employee comparison and trend charts (next iteration)

## Non-functional requirements
- HTTPS only
- Supabase Row Level Security on all tenant data
- Admin MFA recommended
- No service-role key in client applications
- No call recording in MVP
- Privacy notice, employee notice, retention and deletion policy before production
- Backups and account offboarding procedure

## Acceptance criteria
1. Admin can authenticate and see all records.
2. Employee A cannot read Employee B's customer or call records.
3. Employee can create a SIM or WhatsApp business call record.
4. Employee can add feedback and follow-up date.
5. Admin can filter and export call records.
6. Deactivated employee cannot continue using the service.
