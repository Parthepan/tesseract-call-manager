-- Tesseract Call Manager MVP schema
-- Run in a fresh Supabase project's SQL Editor.

create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null,
  role text not null default 'employee' check (role in ('admin','employee')),
  whatsapp_business_number text,
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.customers (
  id uuid primary key default gen_random_uuid(),
  employee_id uuid not null references public.profiles(id),
  customer_name text not null,
  phone_number text,
  company_name text,
  email text,
  notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.call_records (
  id uuid primary key default gen_random_uuid(),
  employee_id uuid not null references public.profiles(id),
  customer_id uuid references public.customers(id) on delete set null,
  customer_name text not null,
  customer_phone text,
  channel text not null check (channel in ('SIM','WHATSAPP')),
  direction text not null check (direction in ('INCOMING','OUTGOING')),
  call_started_at timestamptz not null,
  duration_seconds integer not null default 0 check (duration_seconds >= 0),
  call_status text not null check (call_status in ('ANSWERED','UNANSWERED','DECLINED','UNKNOWN')),
  feedback text check (feedback in ('POSITIVE','NEGATIVE','NEUTRAL','INTERESTED','NOT_INTERESTED')),
  remarks text,
  followup_at timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists public.followups (
  id uuid primary key default gen_random_uuid(),
  employee_id uuid not null references public.profiles(id),
  customer_id uuid references public.customers(id) on delete set null,
  call_record_id uuid references public.call_records(id) on delete set null,
  title text not null,
  due_at timestamptz not null,
  status text not null default 'PENDING' check (status in ('PENDING','DONE','CANCELLED')),
  created_at timestamptz not null default now()
);

create table if not exists public.audit_logs (
  id uuid primary key default gen_random_uuid(),
  actor_id uuid references public.profiles(id),
  action text not null,
  entity_type text not null,
  entity_id uuid,
  details jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create index if not exists idx_customers_employee on public.customers(employee_id);
create index if not exists idx_calls_employee_time on public.call_records(employee_id, call_started_at desc);
create index if not exists idx_calls_customer on public.call_records(customer_id);
create index if not exists idx_followups_employee_due on public.followups(employee_id, due_at);

create or replace function public.is_admin()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1 from public.profiles
    where id = auth.uid() and role = 'admin' and is_active = true
  );
$$;

create or replace function public.is_active_user()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1 from public.profiles
    where id = auth.uid() and is_active = true
  );
$$;

alter table public.profiles enable row level security;
alter table public.customers enable row level security;
alter table public.call_records enable row level security;
alter table public.followups enable row level security;
alter table public.audit_logs enable row level security;

-- Profiles: admin sees all; employee sees own profile.
create policy "profiles_read_own_or_admin" on public.profiles
for select to authenticated
using ((id = auth.uid() and public.is_active_user()) or public.is_admin());

-- Profile updates are deliberately admin-only in the MVP.
create policy "profiles_admin_update" on public.profiles
for update to authenticated
using (public.is_admin())
with check (public.is_admin());

create policy "customers_read_own_or_admin" on public.customers
for select to authenticated
using ((employee_id = auth.uid() and public.is_active_user()) or public.is_admin());

create policy "customers_insert_own_or_admin" on public.customers
for insert to authenticated
with check ((employee_id = auth.uid() and public.is_active_user()) or public.is_admin());

create policy "customers_update_own_or_admin" on public.customers
for update to authenticated
using ((employee_id = auth.uid() and public.is_active_user()) or public.is_admin())
with check ((employee_id = auth.uid() and public.is_active_user()) or public.is_admin());

create policy "customers_delete_own_or_admin" on public.customers
for delete to authenticated
using ((employee_id = auth.uid() and public.is_active_user()) or public.is_admin());

create policy "calls_read_own_or_admin" on public.call_records
for select to authenticated
using ((employee_id = auth.uid() and public.is_active_user()) or public.is_admin());

create policy "calls_insert_own_or_admin" on public.call_records
for insert to authenticated
with check ((employee_id = auth.uid() and public.is_active_user()) or public.is_admin());

create policy "calls_update_own_or_admin" on public.call_records
for update to authenticated
using ((employee_id = auth.uid() and public.is_active_user()) or public.is_admin())
with check ((employee_id = auth.uid() and public.is_active_user()) or public.is_admin());

create policy "calls_delete_own_or_admin" on public.call_records
for delete to authenticated
using ((employee_id = auth.uid() and public.is_active_user()) or public.is_admin());

create policy "followups_read_own_or_admin" on public.followups
for select to authenticated
using ((employee_id = auth.uid() and public.is_active_user()) or public.is_admin());

create policy "followups_insert_own_or_admin" on public.followups
for insert to authenticated
with check ((employee_id = auth.uid() and public.is_active_user()) or public.is_admin());

create policy "followups_update_own_or_admin" on public.followups
for update to authenticated
using ((employee_id = auth.uid() and public.is_active_user()) or public.is_admin())
with check ((employee_id = auth.uid() and public.is_active_user()) or public.is_admin());

create policy "followups_delete_own_or_admin" on public.followups
for delete to authenticated
using ((employee_id = auth.uid() and public.is_active_user()) or public.is_admin());

-- Audit log is read-only to clients; create audit events through trusted server-side code.
create policy "audit_read_admin_only" on public.audit_logs
for select to authenticated
using (public.is_admin());

-- Important:
-- 1. Provision profiles from Supabase Dashboard or a trusted server-side admin function.
-- 2. Never allow public self-registration to choose the admin role.
-- 3. The admin account must be created manually in Supabase Auth, then assigned
--    role='admin' in profiles using the SQL Editor while signed in as project owner.
-- 4. Keep service-role/secret keys on trusted servers only.
