# Tesseract Call Manager — MVP Starter

A starter monorepo for a small Tesseract team:
- `android/`: Kotlin + Jetpack Compose employee app (manual call logging MVP)
- `admin-web/`: React + Vite admin dashboard
- `supabase/schema.sql`: PostgreSQL schema, row-level security (RLS), and helper functions

## Important scope and limitations
1. This starter is **source code**, not a compiled APK or deployed service.
2. SIM call-log automation is intentionally not enabled in the MVP. Android call-log permissions are restricted by Google Play policy. Validate enterprise CRM eligibility and obtain approval before implementing `READ_CALL_LOG` or `WRITE_CALL_LOG`.
3. Standard WhatsApp does not expose a general public API for reading personal WhatsApp voice-call history. WhatsApp business calls are entered manually in this MVP. Each employee's WhatsApp number is stored in their profile as a business contact number, not monitored.
4. Employees should only enter business-related customer calls. Do not collect personal call history, message contents, recordings, or private contacts.
5. The Android app currently contains a small offline-friendly UI skeleton. Supabase authentication/API wiring is the next integration step.

## Recommended setup

### A. Create Supabase project
1. Create a project at https://supabase.com.
2. Open SQL Editor and run `supabase/schema.sql`.
3. In Authentication, create the administrator and employee users.
4. Add a matching row in `profiles` for each auth user:
   - `id`: the user's Auth UID
   - `full_name`: employee name
   - `role`: `admin` for the owner, `employee` for staff
   - `whatsapp_business_number`: employee's business WhatsApp number (optional)
5. Keep the Supabase service-role key server-side only. Never place it in Android or React client code.

### B. Admin web
```bash
cd admin-web
cp .env.example .env
# Set VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY
npm install
npm run dev
```

### C. Android app
Open the `android/` folder in Android Studio (current stable version).
The project uses Kotlin, Compose, and Material 3. Run on an Android device or emulator.
The current prototype uses sample data and does not yet sync to Supabase.

## First production milestones
- Add Supabase Auth to Android and React.
- Create an admin-only employee provisioning workflow using a secure server-side function.
- Add customer CRUD, call record CRUD, follow-up reminders, and CSV export.
- Add privacy notice, consent/employee notice, retention policy, and account deletion process.
- Test RLS using separate admin and employee accounts.
- Review Google Play Data safety declarations and call-log permission eligibility before any call-log automation.

## Data model
- `profiles`: admin and employee identities
- `customers`: business customers assigned to employees
- `call_records`: business SIM or WhatsApp call metadata and outcome
- `followups`: customer follow-up tasks
- `audit_logs`: selected administrative changes

## Security checklist
- RLS is enabled on all application tables.
- Admin role is checked using the profile row.
- Employees can only access their own customers, calls, and follow-ups.
- Never expose the service-role key in a client.
- Use HTTPS, strong passwords, MFA for the admin, and regular backups.
