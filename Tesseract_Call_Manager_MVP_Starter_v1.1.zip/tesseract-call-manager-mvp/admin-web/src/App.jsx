import React, { useEffect, useMemo, useState } from 'react';
import { createClient } from '@supabase/supabase-js';
import { PhoneCall, Users, ThumbsUp, CalendarClock, LogOut, Download, Search } from 'lucide-react';

const url = import.meta.env.VITE_SUPABASE_URL;
const key = import.meta.env.VITE_SUPABASE_ANON_KEY;
const supabase = url && key ? createClient(url, key) : null;

export default function App() {
  const [session, setSession] = useState(null);
  const [profile, setProfile] = useState(null);
  const [calls, setCalls] = useState([]);
  const [employees, setEmployees] = useState([]);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [search, setSearch] = useState('');

  useEffect(() => {
    if (!supabase) return;
    supabase.auth.getSession().then(({ data }) => setSession(data.session));
    const { data: listener } = supabase.auth.onAuthStateChange((_event, next) => setSession(next));
    return () => listener.subscription.unsubscribe();
  }, []);

  useEffect(() => {
    if (session) loadAdminData();
    else { setProfile(null); setCalls([]); setEmployees([]); }
  }, [session]);

  async function loadAdminData() {
    setLoading(true); setError('');
    const { data: p, error: pe } = await supabase.from('profiles').select('*').eq('id', session.user.id).single();
    if (pe || p?.role !== 'admin' || !p?.is_active) {
      setError('This account is not authorized as the Tesseract administrator.');
      await supabase.auth.signOut(); setLoading(false); return;
    }
    setProfile(p);
    const [c, e] = await Promise.all([
      supabase.from('call_records').select('*').order('call_started_at', { ascending: false }).limit(500),
      supabase.from('profiles').select('id,full_name,role,is_active,whatsapp_business_number').eq('role', 'employee').order('full_name')
    ]);
    if (c.error) setError(c.error.message); else setCalls(c.data || []);
    if (e.error) setError(e.error.message); else setEmployees(e.data || []);
    setLoading(false);
  }

  async function signIn(event) {
    event.preventDefault(); setError('');
    if (!supabase) { setError('Set VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY in .env first.'); return; }
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) setError(error.message);
  }

  async function signOut() { await supabase.auth.signOut(); }

  const stats = useMemo(() => ({
    total: calls.length,
    answered: calls.filter(x => x.call_status === 'ANSWERED').length,
    positive: calls.filter(x => ['POSITIVE','INTERESTED'].includes(x.feedback)).length,
    followups: calls.filter(x => x.followup_at && new Date(x.followup_at) >= new Date()).length
  }), [calls]);

  const visibleCalls = calls.filter(c => `${c.customer_name} ${c.customer_phone || ''} ${c.channel}`.toLowerCase().includes(search.toLowerCase()));

  function exportCsv() {
    const cols = ['call_started_at','employee_id','customer_name','customer_phone','channel','direction','duration_seconds','call_status','feedback','remarks','followup_at'];
    const lines = [cols.join(','), ...visibleCalls.map(row => cols.map(k => `"${String(row[k] ?? '').replaceAll('"','""')}"`).join(','))];
    const blob = new Blob([lines.join('\n')], { type: 'text/csv;charset=utf-8' });
    const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = 'tesseract-call-records.csv'; a.click(); URL.revokeObjectURL(a.href);
  }

  if (!session) return <main className="login-wrap"><form className="login card" onSubmit={signIn}>
    <div className="brand-mark">T</div><p className="eyebrow">TESSERACT</p><h1>Call Manager</h1><p className="muted">Administrator sign in</p>
    <label>Email<input type="email" value={email} onChange={e=>setEmail(e.target.value)} required /></label>
    <label>Password<input type="password" value={password} onChange={e=>setPassword(e.target.value)} required /></label>
    {error && <p className="error">{error}</p>}
    <button className="primary">Sign in</button>
    {!supabase && <p className="hint">Configure the Supabase environment variables to connect this dashboard.</p>}
  </form></main>;

  return <main className="shell">
    <header className="topbar"><div><div className="eyebrow light">TESSERACT</div><strong>Call Manager</strong></div><div className="admin"><span>{profile?.full_name || 'Administrator'}</span><button className="icon-btn" onClick={signOut} title="Sign out"><LogOut size={18}/></button></div></header>
    <section className="content">
      <div className="heading"><div><p className="eyebrow">OVERVIEW</p><h1>Admin dashboard</h1><p className="muted">Business call activity across your team.</p></div><button className="secondary" onClick={exportCsv}><Download size={16}/> Export CSV</button></div>
      {error && <p className="error">{error}</p>}
      <div className="stats">
        <Stat icon={<PhoneCall/>} label="Business calls" value={stats.total}/>
        <Stat icon={<Users/>} label="Employees" value={employees.length}/>
        <Stat icon={<ThumbsUp/>} label="Positive / interested" value={stats.positive}/>
        <Stat icon={<CalendarClock/>} label="Upcoming follow-ups" value={stats.followups}/>
      </div>
      <section className="card section-card"><div className="section-title"><div><h2>Employee accounts</h2><p className="muted">Account directory and WhatsApp business numbers</p></div></div>
        <div className="table-wrap"><table><thead><tr><th>Employee</th><th>WhatsApp business number</th><th>Status</th></tr></thead><tbody>
          {employees.map(e=><tr key={e.id}><td>{e.full_name}</td><td>{e.whatsapp_business_number || 'Not provided'}</td><td><span className={e.is_active?'pill good':'pill'}>{e.is_active?'Active':'Disabled'}</span></td></tr>)}
          {!employees.length && <tr><td colSpan="3" className="empty">{loading?'Loading…':'No employee profiles yet.'}</td></tr>}
        </tbody></table></div>
      </section>
      <section className="card section-card"><div className="section-title"><div><h2>Recent business calls</h2><p className="muted">SIM and WhatsApp records entered by employees</p></div><div className="search"><Search size={16}/><input placeholder="Search customer or channel" value={search} onChange={e=>setSearch(e.target.value)}/></div></div>
        <div className="table-wrap"><table><thead><tr><th>Date / time</th><th>Customer</th><th>Channel</th><th>Duration</th><th>Status</th><th>Feedback</th></tr></thead><tbody>
          {visibleCalls.map(c=><tr key={c.id}><td>{new Date(c.call_started_at).toLocaleString()}</td><td>{c.customer_name}<small>{c.customer_phone}</small></td><td>{c.channel}</td><td>{Math.floor(c.duration_seconds/60)}m {c.duration_seconds%60}s</td><td>{c.call_status}</td><td>{c.feedback || '—'}</td></tr>)}
          {!visibleCalls.length && <tr><td colSpan="6" className="empty">{loading?'Loading…':'No call records found.'}</td></tr>}
        </tbody></table></div>
      </section>
      <p className="footer-note">Tesseract Call Manager · MVP · Business records only</p>
    </section>
  </main>;
}

function Stat({icon,label,value}) { return <div className="card stat"><div className="stat-icon">{icon}</div><div><div className="stat-value">{value}</div><div className="muted">{label}</div></div></div>; }
